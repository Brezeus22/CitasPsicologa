document.addEventListener('DOMContentLoaded', function() {
  // Menú desplegable
  const menuToggle = document.getElementById('menu-toggle');
  const menuList = document.getElementById('menu-list');
  menuToggle.addEventListener('click', function(e) {
    e.stopPropagation();
    menuList.style.display = menuList.style.display === 'block' ? 'none' : 'block';
  });
  document.addEventListener('click', function(e) {
    if (!menuToggle.contains(e.target) && !menuList.contains(e.target)) {
      menuList.style.display = 'none';
    }
  });

  // Mostrar solo la sección seleccionada y ocultar los botones principales
  function mostrarSeccion(id) {
    document.getElementById('principal-botones').style.display = 'none';
    document.querySelectorAll('.seccion').forEach(sec => sec.classList.remove('activa'));
    const s = document.getElementById(id);
    if (s) s.classList.add('activa');
    window.scrollTo({ top: s ? s.offsetTop - 40 : 0, behavior: 'smooth' });
    if (menuList) menuList.style.display = 'none';
  }

  // Botones principales
  document.getElementById('btn-cita').addEventListener('click', function(e) {
    e.preventDefault();
    mostrarSeccion('cita');
  });
  document.getElementById('btn-historial').addEventListener('click', function(e) {
    e.preventDefault();
    mostrarSeccion('historial');
  });
  document.getElementById('btn-informe').addEventListener('click', function(e) {
    e.preventDefault();
    mostrarSeccion('informe');
  });

  // Menú superior
  document.getElementById('menu-perfil').addEventListener('click', function(e) {
    e.preventDefault();
    document.getElementById('principal-botones').style.display = 'flex';
    document.querySelectorAll('.seccion').forEach(sec => sec.classList.remove('activa'));
    if (menuList) menuList.style.display = 'none';
  });
  document.getElementById('menu-historial').addEventListener('click', function(e) {
    e.preventDefault();
    mostrarSeccion('historial');
  });
  document.getElementById('menu-cita').addEventListener('click', function(e) {
    e.preventDefault();
    mostrarSeccion('cita');
  });
  document.getElementById('menu-informe').addEventListener('click', function(e) {
    e.preventDefault();
    mostrarSeccion('informe');
  });

  // --- LÓGICA DE FORMULARIO EN DOS PÁGINAS ---
  const form = document.getElementById('form-cita');
  const page1 = document.getElementById('form-page-1');
  const page2 = document.getElementById('form-page-2');
  const btnContinuar = document.getElementById('btn-continuar');
  const btnAtras = document.getElementById('btn-atras');

  if (btnContinuar && btnAtras && page1 && page2) {
    btnContinuar.addEventListener('click', function() {
      let valid = true;
      page1.querySelectorAll('input[required], select[required]').forEach(input => {
        if (!input.value.trim()) valid = false;
      });
      let prevMsg = page1.querySelector('.error-message');
      if (prevMsg) prevMsg.remove();

      if (valid) {
        page1.style.display = 'none';
        page2.style.display = 'block';
      } else {
        const msg = document.createElement('div');
        msg.className = 'error-message';
        msg.textContent = 'Por favor, completa todos los campos obligatorios.';
        page1.appendChild(msg);
        setTimeout(() => { msg.style.display = 'none'; }, 3000);
      }
    });

    btnAtras.addEventListener('click', function() {
      page2.style.display = 'none';
      page1.style.display = 'block';
    });
  }

  // Validación y mensajes para todos los formularios
  function showMessage(form, type, text) {
    let msg = form.querySelector('.' + type + '-message');
    if (!msg) {
      msg = document.createElement('div');
      msg.className = type + '-message';
      form.appendChild(msg);
    }
    msg.textContent = text;
    msg.style.display = 'block';
    setTimeout(() => { msg.style.display = 'none'; }, 3000);
  }

  document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', function(e) {
      e.preventDefault();
      let valid = true;
      form.querySelectorAll('input[required], textarea[required], select[required]').forEach(input => {
        if (!input.value.trim()) valid = false;
      });
      if (valid) {
        showMessage(form, 'success', '¡Guardado exitosamente!');
        form.reset();
        // Si es el formulario de cita, vuelve a la página 1
        if (form.id === 'form-cita' && page1 && page2) {
          page2.style.display = 'none';
          page1.style.display = 'block';
        }
      } else {
        showMessage(form, 'error', 'Por favor, completa todos los campos obligatorios.');
      }
    });
  });

  // --- HORARIOS Y FECHAS DISPONIBLES SEGÚN MODALIDAD ---
  const modalidad = document.getElementById('modalidad');
  const fecha = document.getElementById('fecha');
  const hora = document.getElementById('hora');

  // Simulación de horarios reservados (puedes reemplazar por tu backend)
  // Formato: { 'YYYY-MM-DD': ['09:00 AM', ...], ... }
  const horariosReservados = {
    '2025-06-13': ['09:00 AM', '06:00 PM'],
    '2025-06-14': ['10:00 AM'],
  };

  // Todas las horas posibles (media hora) de 9:00 AM a 8:00 PM
  function generarTodasLasHoras() {
    const horas = [];
    for (let h = 9; h <= 20; h++) {
      horas.push({ h, m: 0 });
      if (h !== 20) horas.push({ h, m: 30 });
    }
    return horas;
  }

  // Convierte a formato 12h am/pm Venezuela
  function formatoHora(h, m) {
    let sufijo = h < 12 ? 'AM' : 'PM';
    let hora12 = h % 12;
    if (hora12 === 0) hora12 = 12;
    return (
      (hora12 < 10 ? '0' : '') + hora12 + ':' + (m === 0 ? '00' : '30') + ' ' + sufijo
    );
  }

  // Valida si la hora está dentro del horario permitido según modalidad y día
  function esHoraPermitida(modalidad, diaSemana, h, m) {
    if (modalidad === 'presencial') {
      if (diaSemana >= 1 && diaSemana <= 5) {
        // Lunes a viernes: 9:00-12:00 y 13:00-16:00
        if ((h >= 9 && h < 12) || (h >= 13 && h < 16)) return true;
      } else if (diaSemana === 6) {
        // Sábado: 9:00-13:00
        if (h >= 9 && h < 13) return true;
      }
    } else if (modalidad === 'online') {
      if (diaSemana >= 1 && diaSemana <= 5) {
        // Lunes a viernes: 6:00pm-8:00pm
        if (h >= 18 && h <= 20) return true;
      } else if (diaSemana === 6) {
        // Sábado: 4:00pm-7:00pm
        if (h >= 16 && h <= 19) return true;
      }
    }
    return false;
  }

  function getDayOfWeek(dateString) {
    // 0: domingo, 1: lunes, ..., 6: sábado
    return new Date(dateString).getDay();
  }

  function actualizarHoras() {
    hora.innerHTML = '<option value="">Seleccione</option>';
    const mod = modalidad.value;
    const fechaVal = fecha.value;
    if (!mod || !fechaVal) return;

    const diaSemana = getDayOfWeek(fechaVal);
    const todasHoras = generarTodasLasHoras();
    const reservados = horariosReservados[fechaVal] || [];

    if (diaSemana === 0) {
      // Domingo no hay consulta
      hora.innerHTML = '<option value="">Horario no laborable</option>';
      hora.disabled = true;
      return;
    }
    hora.disabled = false;

    todasHoras.forEach(({ h, m }) => {
      const horaStr = formatoHora(h, m);
      const option = document.createElement('option');
      option.value = horaStr;
      option.textContent = horaStr;

      if (!esHoraPermitida(mod, diaSemana, h, m)) {
        option.disabled = true;
        option.className = 'hora-reservada';
        option.textContent += ' (cerrado)';
      } else if (reservados.includes(horaStr)) {
        option.disabled = true;
        option.className = 'hora-reservada';
        option.textContent += ' (reservado)';
      }
      hora.appendChild(option);
    });
  }

  if (modalidad && fecha && hora) {
    modalidad.addEventListener('change', function() {
      actualizarHoras();
      fecha.value = '';
      hora.innerHTML = '<option value="">Seleccione</option>';
    });
    fecha.addEventListener('change', actualizarHoras);
  }

  // Validar si selecciona un horario reservado o cerrado
  hora.addEventListener('change', function() {
    const fechaVal = fecha.value;
    const diaSemana = getDayOfWeek(fechaVal);
    const mod = modalidad.value;
    const valor = hora.value;
    const reservados = horariosReservados[fechaVal] || [];

    // Buscar la hora seleccionada en formato 24h
    let partes = valor.match(/^(\d+):(\d+) (AM|PM)$/);
    let h = 0, m = 0;
    if (partes) {
      h = parseInt(partes[1], 10);
      m = parseInt(partes[2], 10);
      if (partes[3] === 'PM' && h !== 12) h += 12;
      if (partes[3] === 'AM' && h === 12) h = 0;
    }

    if (diaSemana === 0 || !esHoraPermitida(mod, diaSemana, h, m)) {
      showMessage(form, 'error', 'Cerrado');
      hora.value = '';
    } else if (reservados.includes(valor)) {
      showMessage(form, 'error', 'Reservado');
      hora.value = '';
    }
  });

  // Dinámica de método de pago según modalidad
  const pago = document.getElementById('pago');
  function actualizarPago() {
    const value = modalidad.value;
    pago.innerHTML = '<option value="">Seleccione</option>';
    if (value === 'presencial') {
      pago.innerHTML += '<option value="pago_movil">Pago móvil</option>';
      pago.innerHTML += '<option value="transferencias">Transferencias</option>';
      pago.innerHTML += '<option value="efectivo">Efectivo</option>';
    } else if (value === 'online') {
      pago.innerHTML += '<option value="pago_movil">Pago móvil</option>';
      pago.innerHTML += '<option value="transferencias">Transferencias</option>';
    }
  }
  if (modalidad) modalidad.addEventListener('change', actualizarPago);
  actualizarPago();
});

// Simulación de descarga de informe
function descargarInforme() {
  alert('Descargando informe médico...');
  // window.location.href = 'ruta/al/informe.pdf';
}